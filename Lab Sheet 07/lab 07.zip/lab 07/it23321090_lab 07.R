setwd("C:\\Users\\it23321090\\Desktop\\lab 07")

#Problem 01
min_time <- 0 
max_time <- 30 
p_10 <- punif(10, min = min_time, max = max_time) - punif(0, min = min_time, max = max_time)
p_10

#Problem 02
min_time_train <- 0 
max_time_train <- 40
p_train <- punif(25, min = min_time_train, max = max_time_train) - punif(10, min = min_time_train, max = max_time_train)
p_train

#Problem 03
lambda <- 1/3
p_update <- pexp(2, rate = lambda)
p_update

#Problem 04.A
mean_iq <- 100
sd_iq <- 15
p_iq_above_130 <- 1 - pnorm(130, mean = mean_iq, sd = sd_iq)
p_iq_above_130

#Problem 04.B
iq_95th_percentile <- qnorm(0.95, mean = mean_iq, sd = sd_iq)
iq_95th_percentile
